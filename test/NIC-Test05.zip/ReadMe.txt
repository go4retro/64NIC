
NIC-Test v0.5 by Devia/Ancients
-------------------------------

This program is for testing the stability of Commodore 64 ethernet cards based
on the Crystal Semiconductors CS8900A chip.

Supported Ethernet Chips:
 - Crystal LAN CS8900A in all revisions.

Supported Ethernet Cards:
 - RR-Net, old and new versions
 - The Final Ethernet (TFE), original and revised layouts
 - FB-Net
 - Net64
 - 64NIC
 - CCCC 64NIC+

Supported Platforms:
 - All C64 models, SX-64 and all C128 models in 64 mode
 - Retro Replay
 - MMC64 (*)(**)
 - MMC Replay
 - IDE64 v4.1
 - 1541 Ultimate (***)
 
(*) - The Clock-Port of the MMC64 is probed before anything in it's pass-through 
port.
(**) - Currently the detection algorithm won't work properly on the pass-through
port in all cases.
(***) - The Ethernet Option needs to be enabled and it has to emulate one of the
supported ethernet cards.


The ethernet chip will be put into internal loop-back mode, so it is not 
necessary to have an ethernet cable connected. The program will continuously send 
out 128 bytes of data to the ethernet chip's frame-buffer and then read back that 
very same data.

The data displayed on screen is the 128 bytes of data being moved back and 
forth. Whenever corruption or errors of any kind are detected, the overall
border color will change to reflect this. The majority of its color will be either
green or red, indicating if errors are detected or not. (yes, green is good!)

You can easily see if some bytes differ from the fill pattern of $ff.
However, several controls are available to influence what you see:

PAUSE:
 - You can press 'P' to pause the program. This will freeze the packet flow and
   and the screen will light in the color of the "state" of the last packet
   received, which also will be the packet displayed on screen.
 - Pressing 'SHIFT+P' will allow you to Single Step
 - Holding 'SPACE' will freeze everything without regard to screen refresh.
   (read: the data displayed might contain data from current and last packet)

RESET:
 - Pressing 'R' will reset the ethernet chip and re-initialize it.
 - Pressing 'LSHIFT+R' will only re-initialize
 - Pressing 'RSHIFT+R' will only reset. This will drop all packets.
 
RECYCLE:
 - Pressing 'Y' will enable recycling of the buffer. This means that whatever is
   received from the ethernet card will be copied back to the send buffer and
   send to the ethernet card again. This also means that errors will propagate,
   making it more obvious what type of errors you are having.

SPEED:
 - Pressing 'S' will cycle through 8 different speeds.

RESTORE:
 - Hit 'RESTORE' to restart the program completely. Useful if you hotswap some
   I/O map jumpers or likewise.

SPRITES:
 - Pressing 0 through 7 will enable or disable sprites 0 through 7. The last
   sprite which got enabled can be moved around the screen using the cursor
   keys. Initially, Sprite 0 is placed on a line known to cause intermittent
   failures in implementations with less than optimally timed chip select.

BANKING:
 - Pressing 'I' will test banking of the I/O space in which the NIC is mapped.
   If the border turns red and the Lost Packets counter starts counting up, this
   means that the NIC cannot be banked out of I/O space and replaced with RAM.
   If nothing seems to happen when pressing 'I' that simply means that the NIC
   was successfully banked out and back in again. However, this does not mean
   that banking works as it should for the entire I/O area!
   

Near the bottom of the screen are some statistics:

"SENT/RECEIVED" - Shows packets sent and received. The received packets are
  including corrupted ones.

"LOST/BAD LENGTH" - Shows lost packets and packets with wrong length. Lost
packets got send, but never got received. Remember we are in internal loop-back
here, so this is NOT good. The packets with wrong length are likely to also
be corrupt, but not necessarily!

"CORRUPTED/OK" - Shows number of corrupted vs. OK packets. Corrupted packets
are found by comparing the received result with what was sent.




Questions/requests/reports/whatever - feel free to mail me..

Devia@ancients.dk

